program Example;
var x, y: integer;
begin
  x := 10;
  y := x + 20;
end.
